import os
import base64
import requests
import json
import time
import pandas as pd  # pandas for CSV export
from dotenv import load_dotenv

load_dotenv()
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")

def get_token():
    auth_string = f"{CLIENT_ID}:{CLIENT_SECRET}"
    auth_bytes = auth_string.encode("utf-8")
    auth_base64 = base64.b64encode(auth_bytes).decode("utf-8")

    url = "https://accounts.spotify.com/api/token"
    headers = {
        "Authorization": f"Basic {auth_base64}",
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {"grant_type": "client_credentials"}
    res = requests.post(url, headers=headers, data=data)
    res.raise_for_status()
    return res.json()["access_token"]

def get_artist_data(token, artist_name):
    url = "https://api.spotify.com/v1/search"
    headers = {"Authorization": f"Bearer {token}"}
    params = {"q": artist_name, "type": "artist", "limit": 1}
    res = requests.get(url, headers=headers, params=params)
    data = res.json()
    if data.get("artists") and data["artists"]["items"]:
        artist = data["artists"]["items"][0]
        return {
            "id": artist["id"],
            "name": artist["name"],
            "genres": artist["genres"],
            "followers": artist["followers"]["total"],
            "popularity": artist["popularity"]
        }
    return None

def get_top_tracks(token, artist_id):
    url = f"https://api.spotify.com/v1/artists/{artist_id}/top-tracks"
    headers = {"Authorization": f"Bearer {token}"}
    res = requests.get(url, headers=headers)
    if res.status_code != 200:
        return []
    return res.json().get("tracks", [])[:10]

def get_audio_features(token, track_ids):
    if not track_ids:
        return []
    url = f"https://api.spotify.com/v1/audio-features"
    headers = {"Authorization": f"Bearer {token}"}
    params = {"ids": ",".join(track_ids)}
    res = requests.get(url, headers=headers, params=params)
    if res.status_code != 200:
        return [None] * len(track_ids)
    return res.json().get("audio_features", [])

def fetch_artists_top_tracks(token, artist_names):
    all_data = []
    for name in artist_names:
        artist = get_artist_data(token, name)
        if not artist:
            continue
        tracks = get_top_tracks(token, artist["id"])
        track_ids = [t["id"] for t in tracks]
        features_list = get_audio_features(token, track_ids)

        for t, f in zip(tracks, features_list):
            artist_country = t["available_markets"][0] if t["available_markets"] else None
            track_data = {
                "track_name": t["name"],
                "artist_name": artist["name"],
                "artist_genres": ",".join(artist["genres"]),
                "artist_followers": artist["followers"],
                "artist_popularity": artist["popularity"],
                "album_name": t["album"]["name"],
                "release_date": t["album"]["release_date"],
                "popularity": t["popularity"],  # approximate listens
            }
            all_data.append(track_data)
            time.sleep(0.1)
    return all_data

if __name__ == "__main__":
    token = get_token()
    artists_list = [
        "Taylor Swift",
        "Bad Bunny",
        "Drake",
        "The Weeknd",
        "Ariana Grande",
        "Ed Sheeran",
        "Eminem",
        "Justin Bieber",
        "Billie Eilish",
        "Kanye West",
        "Post Malone",
        "BTS",
        "Travis Scott",
        "Coldplay",
        "Rihanna",
        "Kendrick Lamar",
        "Bruno Mars",
        "J Balvin",
        "Dua Lipa",
        "Imagine Dragons",
        "Juice WRLD",
        "David Guetta",
        "XXXTENTACION",
        "Lana Del Rey",
        "KAROL G",
        "Maroon 5",
        "Lady Gaga",
        "Ozuna",
        "Future",
        "Calvin Harris",
        "Khalid",
        "Beyoncé",
        "Linkin Park",
        "Shawn Mendes",
        "Queen",
        "Sam Smith"
        "One Direction",
        "Adele",
        "SZA",
        "Anuel AA",
        "Harry Styles",
        "Metro Boomin",
        "Shakira",
        "Chris Brown",
        "J.Cole",
        "Arctic Monkeys",
        "Daddy Yankee",
        "Peso Pluma",
        "Doja Cat",
        "Morgan Wallen",
        "Feid",
        "Olivia Rodrigo",
        "The Beatles",
        "Arijit Singh",
        "Katy Perry",
        "Pritam",
        "Maluma",
        "Selena Gomez",
        "21 Savage",
        "The Chainsmokers",
        "Nicki Minaj",
        "Tyler, The Creator",
        "Sia",
        "Lil Uzi Vert",
        "Rauw Alejandro",
        "Junior H",
        "Twenty One Pilots",
        "Halsey",
        "Miley Cyrus",
        "Myke Towers",
        "Disney",
        "Fuerza Regida",
        "Lil Baby",
        "Red Hot Chili Peppers",
        "Marshmello",
        "Avicii",
        "OneRepublic",
        "Suicideboys",
        "Sabrina Carpenter",
        "Michael Jackson",
        "Frank Ocean",
        "Farruko",
        "Kygo",
        "Camila Cabello",
        "Pitbull",
        "Natanael Cano",
        "Mac Miller",
        "The Neighbourhood",
        "Lil Peep",
        "Elton John",
        "Metallica",
        "Zach Bryan",
        "Charlie Puth",
        "Jason Derulo",
        "Luke Combs",
        "Romeo Santos",
        "Hozier",
        "Gunna",
        "AC/DC",
        "BLACKPINK"
    ]
    data = fetch_artists_top_tracks(token, artists_list)

    # Convert to pandas DataFrame
    df = pd.DataFrame(data)

    # Save to CSV
    df.to_csv("spotify_top_tracks.csv", index=False, encoding="utf-8")

    print("Data saved to spotify_top_tracks.csv")
